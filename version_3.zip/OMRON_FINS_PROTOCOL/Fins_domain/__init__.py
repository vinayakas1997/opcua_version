"""
FINS domain-specific logic
"""

__version__ = "0.1.0"
