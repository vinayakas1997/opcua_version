"""
Main package initialization
"""

__version__ = "0.1.0"
